README

Spencer Woodworth
CSC 473 Ray Tracer

To run: 

$ make
$ ./RayTracer 640 480 -I simple.pov

TGA file will be saved in the working directory as output.tga

Working: 
All features required for Program Part 1 are working.


